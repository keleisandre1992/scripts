scoAPI.LMSSetValue("cmi.core.lesson_status","completed");
scoAPI.LMSCommit("");
exitPage();