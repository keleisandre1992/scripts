document.frames[0].document.frames[1].pipwerks.SCORM.data.set("cmi.core.lesson_status","completed");
top.close();