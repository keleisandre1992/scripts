//Navigate to top level lesson and execute.

pipwerks.SCORM.status("set", "completed");
pipwerks.SCORM.set("cmi.success_status", "passed");
