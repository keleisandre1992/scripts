```
doSetValue("cmi.success_status", "passed");
doSetValue("cmi.completion_status","completed");
doSetValue("cmi.exit", "normal");
doSetValue("adl.nav.request", "exitAll");
doSetValue("cmi.score.scaled", 0.9);
doSetValue("cmi.score.raw", 90);
doCommit();
top.close();
```
