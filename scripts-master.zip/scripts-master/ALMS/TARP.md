<pre><code>
//Navigate to top level lesson and execute.

lmsManager.setValue("cmi.completion_status", "completed");
lmsManager.setValue("cmi.success_status", "passed");
lmsManager.setValue("adl.nav.request", "exitAll");
</code></pre>
