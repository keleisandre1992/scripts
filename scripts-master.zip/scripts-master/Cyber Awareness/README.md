<h1>Instructions for the Old Challenge</h1>

<ul>
<li>Once you have the Cyber Awareness Challenge open and on the Task List section ...</li>
<li>Press the F12 key to open up the Developer tools for Internet Explorer.
<ul><li>Find and click on the CONSOLE tab and select it.</li></ul></li>
<li>Copy the following code and paste it into the textbox at the bottom of the console tab.</li>
<li>Either click the green play arrow to the right of the text box or hold CTRL and press ENTER.</li>
<li>The page will reload and everything will be "completed". The score really doesn't matter so long as there is no RED score.</li>
<li>Now to completely finish click on the section labeled "Home Computer Use" and follow it as normal to complete the challenge.</li>
</ul>

Will work on updated version when I get the time.