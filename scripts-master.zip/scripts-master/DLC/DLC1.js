window.opener.scorm.set("cmi.completion_status","completed");
window.opener.scorm.set("cmi.success_status","passed");
window.opener.scorm.set("cmi.score.raw",90);
window.opener.scorm.set("cmi.score.scaled",0.9);
window.opener.scorm.commit();
window.close();
