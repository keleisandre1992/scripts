<h1>NOTES</h1>
This is used to "Green check mark" the current topic when the green half bubble/circle is present.</br>
Once you have the green check mark continue to next lesson.</br>
</br>
<h3>TESTS</h3>
Tests take away the "Next Lesson" button.</br>
Simply refresh the page once you have the green check mark.</br>
The next lesson button will be present again when page refreshes.
