# This branch may contain more advanced methods and have not, and can not be tested by me, therefore ... again, USE AT OWN RISK

# Collection of scripts for the lazy ... >.>

The scripts/codes included above all can be used with your browsers "Developer Tools". To use the developer tools follow these steps:
1. Open your class in Internet Explorer.
2. Press the F12 key when your class is fully loaded. This will open the developer tools.
3. Click on the "Console" tab of the developer tools window.
4. Paste the code in the text box at the bottom of the console tab.
   1. If the code is one line then you can simply press the ENTER key.
   2. If the code is more than one line then you have to either manually click on the green Play arrow or hold CTRL and press ENTER.
5. At this point the results will vary for the code being used and follow up directions will be included as needed.

## *Calling All Scripters!!!*
As I will soon no longer have access to most military online education courses I would like to open this repo to contributors to keep the scripts alive and updated. Please feel free to fork this repo, make changes, and submit a pull request with your changes. Please make sure to add comments or remarks for reviewing. Comments/Remarks will be removed after merge to keep the amount copied and pasted to a minimum.

This is NOT contracted by the military, therefore, nothing defined as actual hacking will be allowed. These are, but not limited too, the following and will be denied:
- SQL Injections (To include second hand)
- Database manipulations
- Attempting to retrieve another users information
- Attempting to gain access other than your own
- Buffer overflow exploits
- Session Hijacking
- Cookie stealing
- etc...

That said, you may use/submit javascript to attempt to bypass what is needed in order to gain course completion.
Some courses also check time elapsed, so keep that in mind.

As always, these scripts are "use at own risk". I will NOT be held responsible if actions are taken against you. You have been disclaimed!


Enjoy :D

