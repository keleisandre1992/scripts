The scripts/codes included above all can be used with the Internet Explorer Developer Tools. To use the developer tools follow these steps:</br></br>
<ol>
  <li>Open your class in Internet Explorer.</li>
  <li>Press the F12 key when your class is fully loaded. This will open the developer tools.</li>
  <li>Click on the Console tab of the developer tools window.</li>
  <li>Paste the code in the text box at the bottom of the console tab.</li>
  <ol>
    <li>If the code is one line then you can simply press the ENTER key.</li>
    <li>If the code is more than one line then you have to either manually click on the green Play arrow or hold CTRL and press ENTER.</li>
  </ol>
  <li>At this point the results will vary for the code being used and follow up directions will be included as needed.</li>
</ol>
