/*
* Open a class and start the video, after it's playing, pause. Hit F12, Dev
* Options, go to Console, paste the following code. It should enable the
* slider on the video progress bar temporarily. Then just drag the slider to
* the end of the video with like 5-10 seconds left and let it play out. It
* should hit the end and finish for you marking the section complete.
*/

Control.pagePanel.enableProgressBar(true)
